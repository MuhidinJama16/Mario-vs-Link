"use strict";

// Program Title

// Global Variable
let count = 0;
let counting = 0;
let counti = 0;

document.getElementById('mario-btn').addEventListener('click', setMario);
document.getElementById('link-btn').addEventListener('click', setLink);
document.getElementById('calc-btn').addEventListener('click', setValues);
document.getElementById('battle-btn').addEventListener('click', setTotal);
document.getElementById('kirby-btn').addEventListener('click', setKirby);




// Function
function setMario() {
    document.body.style.backgroundColor = 'pink';
    document.getElementById('image').src = 'images/mario.png';

    // Update Variable
    count = count + 1;

    // Display New Value
    document.getElementById('counter').innerHTML = count;    
    
    let message = 'The Mushroom Kingdom';

    document.getElementById('hero').innerHTML = message;

    let message2 = 'Princess Peach';

    document.getElementById('interest').innerHTML = message2;

    let message3 = 'Bowser';

    document.getElementById('nemesis').innerHTML = message3;


    console.log('The Mushroom Kingdom');
    console.log(typeof('The Mushroom Kingdom'));

    console.log('Princess Peach');
    console.log(typeof('Princess Peach'));

    console.log('Bowser');
    console.log(typeof('Bowser'));


}



function setLink() {
    document.body.style.backgroundColor = 'lightgreen';
    document.getElementById('image').src = 'images/link.png';
     
    // Update Variable
    counting = counting + 1;

    // Display New Value
    document.getElementById('counter2').innerHTML = counting;    

    let message = 'Hyrule';

    document.getElementById('hero').innerHTML = message;

    let message2 = 'Princess Zelda';

    document.getElementById('interest').innerHTML = message2;

    let message3 = 'Ganondorf';

    document.getElementById('nemesis').innerHTML = message3;


    console.log('Hyrule');
    console.log(typeof('Hyrule'));

    console.log('Princess Zelda');
    console.log(typeof('Princess Zelda'));

    console.log('Ganondorf');
    console.log(typeof('Ganondorf'));
}


function setValues() {
    let marioStrength = Number(document.getElementById('ms-input').value);
    let marioDefence = Number(document.getElementById('md-input').value);
    let linkStrength = Number(document.getElementById('ls-input').value);
    let linkDefence = Number(document.getElementById('ld-input').value);
    
    console.log('marioStrength');
    console.log(typeof('marioStrength'));

    console.log('marioDefence');
    console.log(typeof('marioDefence'));

    console.log('linkStrength');
    console.log(typeof('linkStrength'));

    console.log('linkDefence');
    console.log(typeof('linkDefence'));


    let message = Math.floor( 2 * marioStrength / linkDefence + 5);
    let message2 = Math.floor((linkStrength + 15) / marioDefence);
    document.getElementById('output1').innerHTML = message;
    document.getElementById('output2').innerHTML = message2;
}

function setTotal () {
    let marioStrength = Number(document.getElementById('ms-input').value);
    let marioDefence = Number(document.getElementById('md-input').value);
    let linkStrength = Number(document.getElementById('ls-input').value);
    let linkDefence = Number(document.getElementById('ld-input').value);
    
    console.log('marioStrength');
    console.log(typeof('marioStrength'));

    console.log('marioDefence');
    console.log(typeof('marioDefence'));

    console.log('linkStrength');
    console.log(typeof('linkStrength'));

    console.log('linkDefence');
    console.log(typeof('linkDefence'));


    let madlib =  'A' + plumber + 'uses a plunger to unclog flooded sinks or toliets' + 'Math.floor( (Math.pow (marioStrength, 2) / linkDefence + 5))';
    let message2 = Math.floor((linkStrength + 15) / marioDefence);

    document.getElementById('madlib').innerHTML
}

// Function
function setKirby() {
    document.body.style.backgroundColor = 'lightcoral';
    document.getElementById('image').src = 'images/SSU_Kirby_artwork.png';

    // Update Variable
    counti = counti + 1;

    // Display New Value
    document.getElementById('counter3').innerHTML = counti;    
    
    let message = 'Dream Land';

    document.getElementById('hero').innerHTML = message;

    let message2 = 'Does not have one';

    document.getElementById('interest').innerHTML = message2;

    let message3 = 'King Dedede';

    document.getElementById('nemesis').innerHTML = message3;


    console.log('Dreram Land');
    console.log(typeof('Dream Land'));

    console.log('Does not have one');
    console.log(typeof('Does  not have one'));

    console.log('King Dedede');
    console.log(typeof('King Dedede'));

}









